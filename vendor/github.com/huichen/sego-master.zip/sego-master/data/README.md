dictionary.txt 词典拷贝自 github.com/fxsjy/jieba
