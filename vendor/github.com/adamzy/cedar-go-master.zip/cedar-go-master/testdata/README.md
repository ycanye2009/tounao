This test dictionry is taken from [jieba](https://github.com/fxsjy/jieba).
